"""The `vfy` command line, per spec/cli.md.

Parsing, rendering, and exit codes. Every decision is made below this file, and nothing here
re-implements one. Importing this module reads no file, no clock, and no environment.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from vfy import __version__, canon, resources, workflow
from vfy.errors import VerifyError

CLI_VERSION = 1

# Three separate things, never merged: the decision, the child's status, and the CLI's health.
EXIT_OK = 0
EXIT_BLOCK = 10
EXIT_HOLD = 11
EXIT_ERROR = 12
EXIT_EXECUTION_FAILED = 13
EXIT_RECORDING_FAILED = 14
EXIT_OPERATIONAL = 1
EXIT_USAGE = 2

_DECISION_EXIT = {"ALLOW": EXIT_OK, "BLOCK": EXIT_BLOCK, "HOLD": EXIT_HOLD, "ERROR": EXIT_ERROR}

_DEVELOPER_TRACEBACK = "VFY_DEVELOPER_TRACEBACK"


def build_parser():
    parser = argparse.ArgumentParser(
        prog="vfy", description="A local, deterministic action gate for consequential software.")
    parser.add_argument("--version", action="version",
                        version="verify-run " + __version__)
    parser.add_argument("--workspace", default=".",
                        help="workspace root (default: the current directory)")
    parser.add_argument("--json", action="store_true", dest="as_json",
                        help="print one canonical JSON object on stdout")
    parser.add_argument("--execution-report", action="store_true",
                        help="with --json run, include versioned execution and recovery facts")
    commands = parser.add_subparsers(dest="command", required=True, metavar="command")

    initialize = commands.add_parser("init", help="create a workspace from a template")
    initialize.add_argument("--template", default="agent-guard", choices=workflow.TEMPLATES,
                            help="which rulebook to start from")

    checker = commands.add_parser("check", help="evaluate a candidate without executing anything")
    checker.add_argument("candidate", help="path to a candidate JSON document")

    runner_parser = commands.add_parser("run", help="gate a command")
    runner_parser.add_argument("--custody-handoff", help="exact opt-in local custody envelope")
    runner_parser.add_argument("--identity", action="append", default=[], metavar="NAME=VALUE",
                               help="a value for one of the rulebook's track fields; repeatable")
    runner_parser.add_argument("argv", nargs=argparse.REMAINDER,
                               metavar="-- command [args...]",
                               help="the exact command, after --")

    replayer = commands.add_parser("replay", help="verify and recompute a stored decision")
    replayer.add_argument("receipt", help="path to a stored receipt")

    receipts = commands.add_parser("receipts", help="list or show local receipts")
    actions = receipts.add_subparsers(dest="action", required=False, metavar="action")
    actions.add_parser("list", help="list committed receipts")
    show = actions.add_parser("show", help="load, verify, and replay one receipt")
    show.add_argument("receipt_id", help="the receipt id")
    for name in ("verify-service-receipt", "reconcile-service-repair", "reconcile-service-repair-current", "check-service-tests", "inspect-service-source-relation"):
        reader = commands.add_parser(name, help="bounded selected service reading; no action or retry")
        reader.add_argument("--request-sha256", required=True,
                            help="independently selected SHA256 of exact JSON stdin bytes")
    session = commands.add_parser("service-accounting-session", help="selected development pool session; no execution")
    session.add_argument("--profile", required=True)
    session.add_argument("--profile-sha256", required=True)
    adoption = commands.add_parser("adopt-service-copy", help="separately authorized managed development copy adoption")
    adoption.add_argument("--profile", required=True)
    adoption.add_argument("--profile-sha256", required=True)
    adoption.add_argument("--request-sha256", required=True)
    lifecycle = commands.add_parser("service-lifecycle", help="explicit paid development preparation, adoption or recovery")
    lifecycle.add_argument("operation", choices=("prepare", "adopt", "recover"))
    lifecycle.add_argument("--profile", required=True)
    lifecycle.add_argument("--profile-sha256", required=True)
    lifecycle.add_argument("--expected-head", required=True)
    lifecycle.add_argument("--payload")
    workflow_service = commands.add_parser("service-workflow", help="held pre-observation development workflow")
    workflow_service.add_argument("operation", choices=("session", "adopt", "recover"))
    for field in ("profile", "profile-sha256", "expected-head"):
        workflow_service.add_argument("--" + field, required=True)
    return parser


def main(argv=None, clock=None, identifiers=None, out=None, err=None):
    """Return a process exit code. No import-time side effect produced any of this."""
    out = sys.stdout if out is None else out
    err = sys.stderr if err is None else err

    parser = build_parser()
    # argparse writes usage errors straight to sys.stderr, so a caller that supplied its own
    # stream would never see them. Redirecting for the parse keeps every diagnostic on the
    # stream this function was given.
    previous_stderr, previous_stdout = sys.stderr, sys.stdout
    sys.stderr, sys.stdout = err, out
    try:
        options = parser.parse_args(sys.argv[1:] if argv is None else list(argv))
    except SystemExit as exit_request:
        # --help and --version exit 0. `code or EXIT_USAGE` would turn that 0 into a usage
        # error, which is exactly what a caller scripting `vfy --version` would trip over.
        code = exit_request.code
        return EXIT_USAGE if code is None else int(code)
    finally:
        sys.stderr, sys.stdout = previous_stderr, previous_stdout

    if options.execution_report and (not options.as_json or options.command != "run"):
        print("--execution-report requires --json and run", file=err)
        return EXIT_USAGE

    if options.command == "inspect-service-source-relation":
        from vfy import service_source_relation_cli
        return service_source_relation_cli.run(request_sha256=options.request_sha256, stdin=sys.stdin.buffer, out=out)
    if options.command == "reconcile-service-repair-current":
        from vfy import service_current_read_cli
        return service_current_read_cli.run(request_sha256=options.request_sha256, stdin=sys.stdin.buffer, out=out)
    if options.command in ("verify-service-receipt", "reconcile-service-repair"):
        from vfy import service_read_cli
        return service_read_cli.run(command=options.command, request_sha256=options.request_sha256,
                                    stdin=sys.stdin.buffer, out=out)

    if options.command == "check-service-tests":
        from vfy import service_tests_cli
        return service_tests_cli.run(request_sha256=options.request_sha256, stdin=sys.stdin.buffer, out=out)

    if options.command == "service-workflow":
        from vfy import service_workflow as service_workflow, service_lifecycle
        import time
        try:
            if options.operation == "session":
                selected_clock = workflow.Clock() if clock is None else clock
                selected_ids = workflow.Identifiers() if identifiers is None else identifiers
                return service_workflow.session(profile=options.profile, profile_sha256=options.profile_sha256,
                    expected_head=options.expected_head, input_fd=sys.stdin.fileno(), output_fd=out.fileno(),
                    session_id=selected_ids.nonce(), now=selected_clock.now_utc, monotonic=time.monotonic)
            ledger = service_workflow.Ledger(options.profile, options.profile_sha256, options.expected_head)
            if options.operation == "adopt":
                raw = sys.stdin.buffer.read(service_workflow.MAX_STDIN + 1)
                if len(raw) > service_workflow.MAX_STDIN: raise ValueError("Request bound exceeded")
                result = service_lifecycle.adopt(ledger, service_workflow.m.load.load_json_bytes(raw))
            else:
                result = service_workflow.recover(ledger)
            print(json.dumps(result, sort_keys=True), file=out)
            return 0
        except Exception as exc:
            print(json.dumps({"state":"REFUSED_OR_UNKNOWN", "reason":str(exc), "automatic_retry":False}),file=out)
            return 12

    if options.command == "service-lifecycle":
        from vfy import service_lifecycle as lifecycle
        try:
            ledger = lifecycle.Ledger(options.profile, options.profile_sha256, options.expected_head)
            if options.operation == "prepare":
                if not options.payload: raise ValueError("Selected payload path required")
                response = lifecycle.prepare(ledger, options.payload)
            elif options.operation == "adopt":
                raw = sys.stdin.buffer.read(lifecycle.MAX_STDIN + 1)
                if len(raw) > lifecycle.MAX_STDIN: raise ValueError("Action request exceeds bound")
                response = lifecycle.adopt(ledger, lifecycle.m.load.load_json_bytes(raw))
            else:
                response = lifecycle.recover(ledger)
            response['full_physical_cost'] = 'UNKNOWN'
            print(json.dumps(response, sort_keys=True), file=out)
            return 0
        except Exception as exc:
            print(json.dumps({'state': 'REFUSED_OR_UNKNOWN', 'reason': str(exc),
                'automatic_retry': False, 'full_physical_cost': 'UNKNOWN'}), file=err)
            return 1
    if options.command == "adopt-service-copy":
        from vfy.service_adoption_cli import adopt_selected
        from vfy.service_read_cli import MAX_STDIN
        try:
            raw = sys.stdin.buffer.read(MAX_STDIN + 1)
            response = adopt_selected(raw, options.request_sha256,
                options.profile, options.profile_sha256)
            print(json.dumps(response, sort_keys=True), file=out)
            return 0
        except (OSError, ValueError, KeyError, TypeError, VerifyError) as exc:
            print(json.dumps({'state': 'ADOPTION_REFUSED_OR_INCOMPLETE',
                'reason': str(exc), 'automatic_retry': False,
                'next': 'Inspect retained state; never resend uncertain adoption.'}), file=err)
            return 1
    if options.command == "service-accounting-session":
        from vfy import service_accounting_cli
        import time
        session_clock = workflow.Clock() if clock is None else clock
        session_identifiers = workflow.Identifiers() if identifiers is None else identifiers
        return service_accounting_cli.run(profile=options.profile, profile_sha256=options.profile_sha256,
                                          input_fd=sys.stdin.fileno(), output_fd=out.fileno(),
                                          session_id=session_identifiers.nonce(), now=session_clock.now_utc,
                                          monotonic=time.monotonic)

    clock = workflow.Clock() if clock is None else clock
    identifiers = workflow.Identifiers() if identifiers is None else identifiers

    try:
        handler = {"init": _init, "check": _check, "run": _run,
                   "replay": _replay, "receipts": _receipts}[options.command]
        return handler(options, clock, identifiers, out, err)
    except VerifyError as typed:
        return _typed_failure(typed, options, out, err)
    except BrokenPipeError:  # pragma: no cover - a closed downstream pipe is not our failure
        return EXIT_OPERATIONAL
    except Exception as defect:  # an unexpected programming defect, never a declared failure
        if os.environ.get(_DEVELOPER_TRACEBACK):
            raise
        print("internal error: %s" % type(defect).__name__, file=err)
        if options.execution_report:
            _emit({"command": "run", "error": "internal_error",
                   "execution_report": _execution_report()}, out)
        return EXIT_OPERATIONAL


# --- commands -------------------------------------------------------------------------------

def _init(options, clock, identifiers, out, err):
    workspace = workflow.initialize(options.workspace, options.template, resources.schema_dir(), resources.template_dir(),
                                    identifiers)
    body = {"command": "init", "template": options.template,
            "runtime_id": workspace.config["runtime_id"],
            "workspace": str(workspace.root), "rulebook": workspace.config["rulebook"]}
    if options.as_json:
        _emit(body, out)
    else:
        print("initialized  %s" % workspace.root, file=out)
        print("  rulebook   %s   (template %s)"
              % (workspace.config["rulebook"], options.template), file=out)
        print("  runtime    %s" % workspace.config["runtime_id"], file=out)
        print("  store      %s" % (Path(workflow.VFY_DIR)), file=out)
        print("  keys were generated in %s; the private halves are never printed."
              % (Path(workflow.VFY_DIR) / "keys"), file=out)
    return EXIT_OK


def _check(options, clock, identifiers, out, err):
    workspace = workflow.open_workspace(options.workspace, resources.schema_dir())
    decision = workflow.check(workspace, options.candidate, clock)
    _render(decision, options, out, err, previewed=True)
    return _DECISION_EXIT[decision.outcome]


def _run(options, clock, identifiers, out, err):
    argv = list(options.argv)
    if argv and argv[0] == "--":
        argv = argv[1:]
    if not argv:
        print("run needs a command after `--`, for example: vfy run -- ./deploy.sh", file=err)
        return EXIT_USAGE

    identity = {}
    for pair in options.identity:
        name, separator, value = pair.partition("=")
        if not separator or not name:
            print("--identity takes NAME=VALUE, for example --identity branch=main", file=err)
            return EXIT_USAGE
        identity[name] = value

    workspace = workflow.open_workspace(options.workspace, resources.schema_dir())
    _warn_on_permissive_keys(workspace, err)
    try:
        decision = workflow.run(workspace, argv, clock, identifiers, identity or None,
                                **({} if options.custody_handoff is None else
                                   {"custody_handoff": options.custody_handoff}))
    except VerifyError as typed:
        if typed.code == "execution_recording_failed":
            # The authorization is spent and the action may have happened. Say so plainly, and
            # say where the signed account of it is: the receipt used to be discarded here, so a
            # store failure erased the only evidence that a command had run.
            preserved = getattr(typed, "preserved_at", None)
            receipt = getattr(typed, "receipt", None)
            print("the attempt finished and its record could not be written (%s)"
                  % getattr(typed, "stage", "unknown"), file=err)
            print("the authorization is consumed; nothing is retried automatically", file=err)
            if preserved:
                print("the signed receipt was preserved, unrecorded, at %s" % preserved, file=err)
                print("it is not a committed record; do not re-run the command", file=err)
            elif receipt is not None:
                print("the signed receipt could not be preserved either; it is reported on "
                      "stdout under --json and nowhere else", file=err)
            # What was already observed about the child. A failure after the launch line may
            # leave the record uncertain; it may not leave the execution unknown, and the
            # completion-clock stage used to report a finished command as though nothing had been
            # seen at all.
            execution = getattr(typed, "execution", None) or {}
            if execution.get("started"):
                print("the action executed; the outcome below was observed before the failure",
                      file=err)
                if execution.get("timed_out"):
                    print("  the action was ended by its timeout", file=err)
                elif execution.get("signal_number") is not None:
                    print("  the action was ended by a signal", file=err)
                else:
                    print("  exit status %s" % execution.get("exit_status"), file=err)
                if receipt is None:
                    print("  no signed receipt exists: it could not be completed", file=err)
            if options.as_json:
                body = {"command": options.command, "error": typed.code,
                        "stage": getattr(typed, "stage", None),
                        "executed": bool(execution.get("started")),
                        "authorization_consumed": True,
                        "exit_status": execution.get("exit_status"),
                        "timed_out": execution.get("timed_out"),
                        "signalled": execution.get("signal_number") is not None,
                        "receipt_id": receipt.receipt_id if receipt is not None else None,
                        "preserved_at": preserved,
                        "receipt": receipt.value() if receipt is not None else None}
                if options.execution_report:
                    availability = ("preserved_uncommitted" if preserved else
                                    "inline_uncommitted" if receipt is not None else "unavailable")
                    body["execution_report"] = _execution_report(
                        launcher=("started" if execution["started"] else "not_started")
                        if "started" in execution else "unknown",
                        consumption="consumed", availability=availability,
                        completion=_completion(execution))
                _emit(body, out)
            return EXIT_RECORDING_FAILED
        raise
    _render(decision, options, out, err)
    if decision.outcome != "ALLOW":
        return _DECISION_EXIT[decision.outcome]
    # A non-zero child does not demote the decision; the code says the action failed.
    return EXIT_OK if decision.exit_status == 0 else EXIT_EXECUTION_FAILED


def _replay(options, clock, identifiers, out, err):
    workspace = workflow.open_workspace(options.workspace, resources.schema_dir())
    record = workflow.replay(workspace, options.receipt)
    body = {"command": "replay", "receipt_id": record.receipt_id, "outcome": record.outcome,
            "verified": True, "replayed": record.replay_verified,
            "authorization_verified": record.authorization_verified,
            "timeline_anomalies": list(record.timeline_anomalies)}
    if options.as_json:
        _emit(body, out)
    else:
        print("%-7s %s" % (record.outcome, record.receipt_id), file=out)
        print("  verification  signature verified", file=out)
        print("  replay        %s"
              % ("recomputed and identical" if record.replay_verified
                 else "not replayed"), file=out)
        if record.authorization_verified:
            print("  authorization verified against the recorded bindings", file=out)
        # Named, not refused. Below the spend line the action may already have happened, so a
        # clock that stepped backward cannot make it un-happen, and this receipt is still the
        # account of it. Silence here would let an impossible timeline read as ordinary.
        for anomaly in record.timeline_anomalies:
            print("  timeline      %s" % anomaly, file=out)
    return _DECISION_EXIT[record.outcome]


def _receipts(options, clock, identifiers, out, err):
    workspace = workflow.open_workspace(options.workspace, resources.schema_dir())
    if getattr(options, "action", None) == "show":
        record = workflow.replay(
            workspace, workspace.vfy / "receipts" / (options.receipt_id + ".json"))
        body = {"command": "receipts.show", "receipt_id": record.receipt_id,
                "outcome": record.outcome, "verified": True,
                "replayed": record.replay_verified}
        if options.as_json:
            _emit(body, out)
        else:
            print("%-7s %s   verified and replayed" % (record.outcome, record.receipt_id),
                  file=out)
        return _DECISION_EXIT[record.outcome]

    listing = workflow.list_receipts(workspace)
    summaries, refused = listing.summaries, listing.refused
    body = {"command": "receipts.list",
            "receipts": [{"receipt_id": s.receipt_id, "created_at": s.created_at,
                          "outcome": s.outcome, "rulebook_id": s.rulebook_id,
                          "rulebook_version": s.rulebook_version,
                          "authorization_id": s.authorization_id, "key_id": s.key_id}
                         for s in summaries],
            "refused": [{"file": r.filename, "code": r.code} for r in refused]}
    if options.as_json:
        _emit(body, out)
    elif not summaries:
        print("no receipts yet" if not refused else "no receipt in this store could be read",
              file=out)
    else:
        for summary in summaries:
            print("%-7s %-28s %s  %s@%s"
                  % (summary.outcome, summary.receipt_id, summary.created_at,
                     summary.rulebook_id, summary.rulebook_version), file=out)
        print("listed from the committed records, which govern", file=out)
    # A damaged artifact is named on the diagnostic stream and never silently dropped. The
    # healthy records above are still listed: one unreadable file is a fact about that file.
    for entry in refused:
        print("refused %s (%s): %s" % (entry.filename, entry.code, entry.message), file=err)
    if refused:
        print("%d artifact(s) in the store could not be read; nothing was deleted"
              % len(refused), file=err)
        return EXIT_OPERATIONAL
    return EXIT_OK


# --- rendering ------------------------------------------------------------------------------

def _render(decision, options, out, err, previewed=False):
    if options.as_json:
        body = {"command": "check" if previewed else "run",
               "outcome": decision.outcome,
               "matched_rule": decision.matched_rule,
               "reasons": [dict(reason) for reason in decision.reasons],
               "receipt_id": decision.receipt_id,
               "receipt_path": decision.receipt_path,
               "executed": decision.executed,
               "exit_status": decision.exit_status,
               "notes": list(decision.notes)}
        if getattr(options, "execution_report", False):
            body["execution_report"] = _execution_report(
                launcher="started" if decision.executed else "not_started",
                consumption="consumed" if decision.nonce_consumed else "not_consumed",
                availability="committed" if decision.receipt_id else "unavailable",
                completion=_completion({"started": decision.executed,
                                        "exit_status": decision.exit_status,
                                        "timed_out": decision.timed_out,
                                        "signal_number": 1 if decision.signalled else None}))
        _emit(body, out)
        return
    rule = ("   rule: " + decision.matched_rule) if decision.matched_rule else ""
    print("%-7s %s%s" % (decision.outcome, decision.summary, rule), file=out)
    for reason in decision.reasons:
        detail = reason.get("evidence_id")
        print("        %s%s: %s"
              % (reason["code"], (" " + detail) if detail else "", reason["message"]), file=out)
    for note in decision.notes:
        print("        %s" % note, file=out)
    if decision.receipt_path:
        print("        receipt %s" % decision.receipt_path, file=out)
    if previewed:
        print("        preview only: nothing was authorized, consumed, or executed", file=out)
    elif decision.outcome == "ALLOW":
        if decision.executed and decision.exit_status is not None:
            print("        executed, exit %d" % decision.exit_status, file=out)
        else:
            print("        the authorized command did not complete", file=out)
    else:
        print("        nothing executed", file=out)


def _completion(observed):
    if observed.get("timed_out"):
        return "timed_out"
    if observed.get("signal_number") is not None:
        return "signalled"
    if observed.get("started") and observed.get("exit_status") is not None:
        return "exited"
    if observed.get("started") is False:
        return "not_started"
    return "unknown"


def _execution_report(*, launcher="unknown", consumption="unknown", availability="unknown",
                      completion="unknown"):
    """Only observed runtime facts; a child exit code is not a checker attestation."""
    recovery = ("new_request_only" if consumption == "not_consumed" else
                "inspect_recorded_attempt" if availability == "committed" else
                "reconcile_before_new_request")
    return {"version": 1, "launcher_execution": launcher,
            "checker_execution": "not_observed", "context_refusal": "not_observed",
            "nonce_consumption": consumption, "receipt_availability": availability,
            "completion": completion, "trust_policy": "supplied_snapshot",
            "automatic_retry_permitted": False, "recovery": recovery}


def _emit(body, out):
    # Canonical because the frozen canonicalizer produced it, not because it is JSON.
    print(canon.canonicalize(body), file=out)


def _typed_failure(typed, options, out, err):
    """Every declared failure renders as one line. No traceback, no key material, no stack."""
    print("%s: %s" % (typed.code, typed), file=err)
    if typed.code in _DECISION_EXIT:  # pragma: no cover - reason codes are not outcome names
        return _DECISION_EXIT[typed.code]
    if getattr(options, "as_json", False):
        body = {"command": options.command, "error": typed.code}
        if getattr(options, "execution_report", False):
            body["execution_report"] = _execution_report()
        _emit(body, out)
    return EXIT_OPERATIONAL


def _warn_on_permissive_keys(workspace, err):
    for which in ("authorization", "receipt"):
        _, permissive = workflow.load_signing_seed(workspace, which)
        if permissive:
            print("warning: the %s signing key is readable beyond its owner" % which, file=err)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
